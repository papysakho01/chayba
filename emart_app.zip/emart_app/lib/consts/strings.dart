const appname = "Chayba";
const appversion = "Version 1.0.0";
const credits = "@Papy SAKHO";
const email = "Email";
const emailHint = "exemple@exemple.com";
const password = "Mot de passe";
const passwordHint = "*******";
const retypePassword = "Retype password";
const name = "Prenom et Nom";
const nameHint = "Baba Male";
const forgetPass = "Mot de passe oublié";
const login = "Se connecter";
const signup = "S'inscrire";
const createNewAccont = "ou, creer un nouveau compte";
const loginWith = "Se connecter avec";
const privacyPolicy = "Politique de confidentialite";
const termsAndCond = "Termes et conditions";
const alreadyHaveAccount = "Deja inscrit? ";
const numTel = "Numero de telephone";
const numTelHint = "+221 77 123 45 67";
const logout = "Se deconnecter";

const home = "Accueil",
    categories = "Categories",
    cart = "Panier",
    account = "Compte",
    livraison = "Livraison";

const searching = "Recherchez...",
    todayDeal = "Produits du jour",
    flashsale = "Vente Flash",
    topSellers = "Top ventes",
    brand = "Marques",
    topCategories = "Top Categories",
    featuredCategories = "Categories Vedettes",
    featuredProduct = "Produits Vedettes",
    epi = "EPI",
    allproducts = "Tout les produits",
    fournitures = "Fournitures",
    imprimerie = "Imprimerie",
    cadeaux = "Cadeaux d'entreprise",
    consommableIT = "Consommables Informatique",
    materiel = "Materiel Informatique",
    froid = "Froid et climatisation",
    nettoiement = "Nettoiement et entretien";

const video = "Video",
    review = "Revision",
    sellerpolicy = "Clause de vente",
    returnpolicy = "Politique de retour",
    supportPolicy = "Support",
    prodmaylike = "Les articles qui peuvent vous interesse";

const wishlist = "Mes favoris", orders = "Mes commandes", message = "Messages";
